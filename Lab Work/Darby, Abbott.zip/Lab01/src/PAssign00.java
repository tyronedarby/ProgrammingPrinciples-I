/**
* File: PAssign00.java
* Class: CSCI 1301
* Author: Tyrone Darby
* Created on: Jun 6, 2016
* Last Modified: Aug 16, 2018
* Description: Display three messages to the console
*/



public class PAssign00 {
	 public static void main(String[] args) {
	        System.out.println("Hello, World!");
	        System.out.println("This is Programming Assignment 0 for CSCI 1301.\n"
	        		+ "I have written my first \"official program\" and it works!\n"
	        		+ "Outputting text is not that hard, and I should make sure I get good at it.");
	    }
}
